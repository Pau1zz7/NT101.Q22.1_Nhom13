import os
from Crypto.Cipher import AES
from Crypto.Util import Counter
from Crypto.Util.Padding import pad

key = b'1234567890123456'
data = os.urandom(1000)
padded_data = pad(data, 16)


def test_error_propagation(mode_name):
    print(f"\nChế độ: {mode_name}")

    if mode_name == 'ECB':
        cipher = AES.new(key, AES.MODE_ECB)
        ct = cipher.encrypt(padded_data)
        iv = None
        decipher = AES.new(key, AES.MODE_ECB)

    elif mode_name == 'CBC':
        iv = os.urandom(16)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        ct = cipher.encrypt(padded_data)
        decipher = AES.new(key, AES.MODE_CBC, iv)

    elif mode_name == 'CFB':
        iv = os.urandom(16)
        cipher = AES.new(key, AES.MODE_CFB, iv)
        ct = cipher.encrypt(padded_data)
        decipher = AES.new(key, AES.MODE_CFB, iv)

    elif mode_name == 'OFB':
        iv = os.urandom(16)
        cipher = AES.new(key, AES.MODE_OFB, iv)
        ct = cipher.encrypt(padded_data)
        decipher = AES.new(key, AES.MODE_OFB, iv)

    elif mode_name == 'CTR':
        ctr = Counter.new(128, initial_value=0)
        cipher = AES.new(key, AES.MODE_CTR, counter=ctr)
        ct = cipher.encrypt(padded_data)
        ctr2 = Counter.new(128, initial_value=0)
        decipher = AES.new(key, AES.MODE_CTR, counter=ctr2)
        iv = None

    ct_list = bytearray(ct)
    ct_list[25] ^= 0x01
    ct_corrupted = bytes(ct_list)

    pt_decrypted = decipher.decrypt(ct_corrupted)
    pt_decrypted = pt_decrypted[:1000]

    diff_bytes = sum(a != b for a, b in zip(data, pt_decrypted))
    print(f"Số byte bản rõ bị hỏng: {diff_bytes}/1000 bytes")
    return diff_bytes

modes = ['ECB', 'CBC', 'CFB', 'OFB', 'CTR']
for m in modes:
    test_error_propagation(m)