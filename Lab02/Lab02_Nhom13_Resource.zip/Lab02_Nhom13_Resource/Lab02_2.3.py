from Crypto.Cipher import DES

def get_bin(data):
    # Chuyển dữ liệu bytes sang chuỗi nhị phân và thêm số 0 ở đầu cho đủ 64 bits
    return bin(int.from_bytes(data, 'big'))[2:].zfill(len(data)*8)

def avalanche_test(key_str):
    # Đảm bảo key có độ dài 8 bytes 
    key = key_str.encode('utf-8') 
    p1 = b'STAYHOME'
    p2 = b'STAYHOMA' # khác nhau kí tự cuối
    
    # Thực hiện mã hóa p1, p2 bằng DES-ECB
    cipher = DES.new(key, DES.MODE_ECB)
    c1 = cipher.encrypt(p1)
    c2 = cipher.encrypt(p2)
    
    # Chuyển kết quả sang dạng chuỗi nhị phân
    b1 = get_bin(c1)
    b2 = get_bin(c2)
    
    # Đếm số bit khác nhau 
    diff_bits = sum(1 for bit1, bit2 in zip(b1, b2) if bit1 != bit2)
    total_bits = len(b1) 
    percent = (diff_bits / total_bits) * 100
    
    print(f"--- Key: {key_str} ---")
    print(f"Cipher 1 (bin): {b1}")
    print(f"Cipher 2 (bin): {b2}")
    print(f"Hamming Distance: {diff_bits}/{total_bits} bits")
    print(f"Tỷ lệ thay đổi  : {percent:.2f}%\n")

# key mặc định
avalanche_test('87654321')

# key là Mã số sinh viên 
avalanche_test('24521388')