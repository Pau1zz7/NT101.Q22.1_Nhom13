import random

# TÍNH LŨY THỪA MODULE 

def modular_pow(a, x, p):
    res = 1
    a = a % p
    while x > 0:
        if x % 2 == 1: # Nếu x lẻ, nhân a vào kết quả
            res = (res * a) % p
        x = x // 2     # Chia đôi x
        a = (a * a) % p # Bình phương a
    return res

# KIỂM TRA SỐ NGUYÊN TỐ (Miller-Rabin)

def miller_rabin(n, k=5):
    if n == 2 or n == 3: return True
    if n <= 1 or n % 2 == 0: return False

    # Viết n-1 dưới dạng 2^r * d
    r = 0
    d = n - 1
    while d % 2 == 0:
        r += 1
        d //= 2

    # Thử nghiệm k lần
    for _ in range(k):
        a = random.randrange(2, n - 1)
        x = modular_pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = modular_pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

def generate_n_bit_prime(bits):
    while True:
        # Sinh số lẻ ngẫu nhiên có độ dài 'bits'
        num = random.getrandbits(bits)
        num |= (1 << (bits - 1)) | 1 
        if miller_rabin(num, 10):
            return num


# ƯỚC CHUNG LỚN NHẤT

def euclidean_gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a


# KẾT QUẢ THỰC THI (Main)

print("--- 1. TẠO SỐ NGUYÊN TỐ ---")
print(f"8-bit prime : {generate_n_bit_prime(8)}")
print(f"16-bit prime: {generate_n_bit_prime(16)}")
print(f"64-bit prime: {generate_n_bit_prime(64)}")

print("\n--- 2. TÌM 10 SỐ NGUYÊN TỐ NHỎ HƠN M_10 ---")
M10 = (2**89) - 1
print(f"Mersenne thứ 10 (M_10) = {M10}")
primes_below_m10 = []
num = M10 - 2 # Bắt đầu từ số lẻ ngay dưới M_10
while len(primes_below_m10) < 10:
    if miller_rabin(num, 10):
        primes_below_m10.append(num)
    num -= 2

for i, p in enumerate(primes_below_m10):
    print(f"Số thứ {i+1}: {p}")

print("\n--- 3. KIỂM TRA SỐ NGẪU NHIÊN < M_10 ---")
test_num = random.randrange(3, M10, 2)
is_p = miller_rabin(test_num, 10)
print(f"Số ngẫu nhiên: {test_num}")
print(f"Có phải số nguyên tố không? -> {is_p}")

print("\n--- 4. TÌM GCD CỦA 2 SỐ LỚN ---")
num1 = random.getrandbits(256)
num2 = random.getrandbits(256)
print(f"Số A: {num1}\nSố B: {num2}")
print(f"GCD(A, B) = {euclidean_gcd(num1, num2)}")

print("\n--- 5. LŨY THỪA MODULE ---")
print(f"7^40 mod 19 = {modular_pow(7, 40, 19)}")