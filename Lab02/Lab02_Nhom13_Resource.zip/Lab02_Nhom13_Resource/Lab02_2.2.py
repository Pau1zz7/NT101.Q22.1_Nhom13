from Crypto.Cipher import AES
from Crypto.Util import Counter

key = b'1234567890123456'
plaintext = b"UIT_LAB_UIT_LAB_UIT_LAB_UIT_LAB_" 
iv = b'0000000000000000' # 

# 1. AES-ECB
cipher_ecb = AES.new(key, AES.MODE_ECB)
ct_ecb = cipher_ecb.encrypt(plaintext)

# 2. AES-CBC
cipher_cbc = AES.new(key, AES.MODE_CBC, iv)
ct_cbc = cipher_cbc.encrypt(plaintext)

# 3. (CFB, OFB, CTR) 
cipher_cfb = AES.new(key, AES.MODE_CFB, iv=iv, segment_size=128)
ct_cfb = cipher_cfb.encrypt(plaintext)

cipher_ofb = AES.new(key, AES.MODE_OFB, iv=iv)
ct_ofb = cipher_ofb.encrypt(plaintext)

cipher_ctr = AES.new(key, AES.MODE_CTR, counter=Counter.new(128, initial_value=0))
ct_ctr = cipher_ctr.encrypt(plaintext)

# Hàm in kết quả
def print_blocks(name, ct):
    print(f"[{name}]")
    print(f"Block 1: {ct[:16].hex()}")
    print(f"Block 2: {ct[16:].hex()}\n")

print_blocks("AES-ECB", ct_ecb)
print_blocks("AES-CBC", ct_cbc)
print_blocks("AES-CFB", ct_cfb)
print_blocks("AES-OFB", ct_ofb)
print_blocks("AES-CTR", ct_ctr)